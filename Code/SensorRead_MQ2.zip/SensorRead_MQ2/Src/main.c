

#include <stdint.h>

#define RCC_AHB1ENR (*(volatile uint32_t*)0x40023830) //Clock Enable
#define RCC_APB2ENR (*(volatile uint32_t*)0x40023844) // ADC1 Enable


#define GPIOB_MODER (*(volatile uint32_t*)0x40020400)

//0x4001 2000+0x00 ADC1-0x4001 2000

#define ADC1_SR (*(volatile uint32_t*)0x40012000)

//0x4001 2000+0x08 -0x4001 2008
#define ADC1_CR2 (*(volatile uint32_t*)0x40012008)

//0x4001 2000+0x34 -0x4001 2034
#define ADC1_SQR3 (*(volatile uint32_t*)0x40012034)

//0x4001 2000+0x4C -0x4001 2034
#define ADC1_DR (*(volatile uint32_t*)0x4001204C)



int main(void)
{
    volatile uint16_t adc_value;


    RCC_AHB1ENR |= (1 << 1);   // GPIOB
    RCC_APB2ENR |= (1 << 8);   // ADC1


    GPIOB_MODER |= (3 << (0 * 2));

    ADC1_SQR3 = 8;

    ADC1_CR2 |= (1 << 0);


    for(volatile int i=0;i<10000;i++);

    while(1)
    {

        ADC1_CR2 |= (1 << 30);


        while(!(ADC1_SR & (1 << 1)));


        adc_value = ADC1_DR;


        ADC1_SR = 0;

        for(volatile int i=0;i<50000;i++);
    }
}
